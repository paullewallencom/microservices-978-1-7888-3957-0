## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/implementing-serverless-microservices-architecture-patterns-video/9781788839570)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Implementing-Serverless-Microservices-Architecture-Patterns-
Code files
